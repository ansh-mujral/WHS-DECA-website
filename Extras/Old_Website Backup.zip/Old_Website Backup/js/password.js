function TheLogin() {

var password = 'huskies';

if (this.document.login.pass.value == password) {
  top.location.href="president.html";
}
else {
  window.alert("Incorrect password, please try again.");
  }
}
